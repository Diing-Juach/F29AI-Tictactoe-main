package ticTacToe;

import java.util.List;
import java.util.Random;

/**
 * A Q-Learning agent with a Q-Table, i.e. a table of Q-Values. This table is implemented in the {@link QTable} class.
 * 
 *  The methods to implement are: 
 * (1) {@link QLearningAgent#train}
 * (2) {@link QLearningAgent#extractPolicy}
 * 
 * Your agent acts in a {@link TTTEnvironment} which provides the method {@link TTTEnvironment#executeMove} which returns an {@link Outcome} object, in other words
 * an [s,a,r,s']: source state, action taken, reward received, and the target state after the opponent has played their move. You may want/need to edit
 * {@link TTTEnvironment} - but you probably won't need to. 
 * @author ae187
 */

/**
 * @author sunil
 *
 */
public class QLearningAgent extends Agent {

	/**
	 * The learning rate, between 0 and 1.
	 */
	double alpha = 0.1;

	/**
	 * The number of episodes to train for
	 */
	int numEpisodes = 10000;

	/**
	 * The discount factor (gamma)
	 */
	double discount = 0.9;

	/**
	 * The epsilon in the epsilon greedy policy used during training.
	 */
	double epsilon = 0.1;

	/**
	 * This is the Q-Table. To get an value for an (s,a) pair, i.e. a (game, move)
	 * pair.
	 * 
	 */

	QTable qTable = new QTable();

	/**
	 * This is the Reinforcement Learning environment that this agent will interact
	 * with when it is training. By default, the opponent is the random agent which
	 * should make your q learning agent learn the same policy as your value
	 * iteration and policy iteration agents.
	 */
	TTTEnvironment env = new TTTEnvironment();

	/**
	 * Construct a Q-Learning agent that learns from interactions with
	 * {@code opponent}.
	 * 
	 * @param opponent     the opponent agent that this Q-Learning agent will
	 *                     interact with to learn.
	 * @param learningRate This is the rate at which the agent learns. Alpha from
	 *                     your lectures.
	 * @param numEpisodes  The number of episodes (games) to train for
	 */
	public QLearningAgent(Agent opponent, double learningRate, int numEpisodes, double discount) {
		env = new TTTEnvironment(opponent);
		this.alpha = learningRate;
		this.numEpisodes = numEpisodes;
		this.discount = discount;
		initQTable();
		train();
	}

	/**
	 * Initialises all valid q-values -- Q(g,m) -- to 0.
	 * 
	 */

	protected void initQTable() {
		List<Game> allGames = Game.generateAllValidGames('X');// all valid games where it is X's turn, or it's terminal.
		for (Game g : allGames) {
			List<Move> moves = g.getPossibleMoves();
			for (Move m : moves) {
				this.qTable.addQValue(g, m, 0.0);
				// System.out.println("initing q value. Game:"+g);
				// System.out.println("Move:"+m);
			}

		}

	}

	/**
	 * Uses default parameters for the opponent (a RandomAgent) and the learning
	 * rate (0.2). Use other constructor to set these manually.
	 */
	public QLearningAgent() {
		this(new RandomAgent(), 0.1, 100000, 0.9);

	}

	/**
	 * Selects a move using the epsilon-greedy strategy.
	 */
	private Move getEpsilonMove(Game g) {
		// Getting the list of all possible moves for the current game state.
		List<Move> moves = g.getPossibleMoves();
		Random random = new Random();

		// Checking if we should explore (random move) or exploit (best move based on
		// Q-values).
		if (random.nextDouble() < epsilon) {
			// Choosing a random move if there are any available.
			if (!moves.isEmpty()) {
				return moves.get(random.nextInt(moves.size()));
			}
		} else {
			// Choosing the move with the maximum Q-value.
			return getMaxQValueMove(g, moves);
		}

		// Returning null if no moves are available.
		return null;
	}

	/**
	 * Implement this method. It should play {@code this.numEpisodes} episodes of
	 * Tic-Tac-Toe with the TTTEnvironment, updating q-values according to the
	 * Q-Learning algorithm as required. The agent should play according to an
	 * epsilon-greedy policy where with the probability {@code epsilon} the agent
	 * explores, and with probability {@code 1-epsilon}, it exploits.
	 * 
	 * At the end of this method you should always call the {@code extractPolicy()}
	 * method to extract the policy from the learned q-values. This is currently
	 * done for you on the last line of the method.
	 */

	public void train() {
		// Iterating through the training episodes
		for (int episode = 0; episode < numEpisodes; episode++) {
			// Playing the game until reaching a terminal state
			while (!this.env.isTerminal()) {
				Game gameState = this.env.getCurrentGameState();

				// Skipping if the game state is already terminal
				if (gameState.isTerminal()) {
					continue;
				}

				// Choosing a move based on the epsilon-greedy strategy
				Move selectedMove = getEpsilonMove(gameState);
				Outcome outcome;

				try {
					// Executing the move and capturing the result
					outcome = this.env.executeMove(selectedMove);
				} catch (IllegalMoveException e) {
					// Handling invalid moves and continue
					System.err.println("Illegal move: " + e.getMessage());
					continue;
				}

				// Calculating the updated Q-value for the state-action pair
				double currentQValue = this.qTable.getQValue(outcome.s, outcome.move);
				double updatedQValue = (1 - this.alpha) * currentQValue
						+ this.alpha * (outcome.localReward + this.discount * maxQvalue(outcome.sPrime));

				// Updating the Q-table with the new Q-value
				this.qTable.addQValue(outcome.s, outcome.move, updatedQValue);
			}

			// Resetting the environment for the next training episode
			this.env.reset();
		}

		// --------------------------------------------------------
		// you shouldn't need to delete the following lines of code.
		this.policy = extractPolicy();
		if (this.policy == null) {
			System.err.println("Unimplemented methods! First implement the train() & extractPolicy methods");
		}
	}

	/**
	 * Extracts the policy from the Q-table by selecting the move with the highest
	 * Q-value for the given state.
	 */
	private Double maxQvalue(Game nextState) {
		if (nextState.isTerminal()) {
			return 0.0; // Returning 0 if the state is terminal
		}

		// Initialising the highestQValue to a very low number
		double highestQValue = Double.NEGATIVE_INFINITY;

		// Iterating over all possible moves from the current state
		for (Move move : nextState.getPossibleMoves()) {
			double currentQValue = this.qTable.getQValue(nextState, move);

			// Updating the highestQValue if the current Q-value is greater
			if (currentQValue > highestQValue) {
				highestQValue = currentQValue;
			}
		}

		// Returning the highest Q-value found among all possible moves
		return highestQValue;
	}

	/**
	 * Selects the move with the highest Q-value from a list of possible moves. It
	 * uses the Q-values stored in the {@code qTable} to evaluate each move and
	 * returns the one with the highest value
	 */
	private Move getMaxQValueMove(Game g, List<Move> moves) {
		Move bestMove = null;
		double maxQValue = Double.NEGATIVE_INFINITY; 

		for (Move move : moves) {
			double currQValue = qTable.getQValue(g, move);
			// Checking if the current Q-value is greater than the maximum Q-value found 
			if (currQValue > maxQValue) {
				maxQValue = currQValue; // Update the maximum Q-value
				bestMove = move; // Update the best move
			}
		}

		return bestMove; // Returning the move with the highest Q-value
	}

	/**
	 * Implement this method. It should use the q-values in the {@code qTable} to
	 * extract a policy and return it.
	 *
	 * @return the policy currently inherent in the QTable
	 */
	public Policy extractPolicy() {
		Policy policy = new Policy();

		// Iterating through all game states present in the Q-table
		for (Game gameSt : this.qTable.keySet()) {
			if (gameSt.isTerminal()) {
				continue;
			}

			Move bestMove = getMaxQValueMove(gameSt, gameSt.getPossibleMoves());
			if (bestMove != null) {
				// Storing the optimal move for the current game state in the policy
				policy.policy.put(gameSt, bestMove);
			} else {
				System.err.println("No valid moves found for game state: " + gameSt);
			}
		}

		return policy; // Returning the constructed Policy object
	}

	public static void main(String a[]) throws IllegalMoveException {
		// Test method to play your agent against a human agent (yourself).
		QLearningAgent agent = new QLearningAgent();

		HumanAgent d = new HumanAgent();

		Game g = new Game(agent, d, d);
		g.playOut();

	}

}